/** Automatically generated file. DO NOT MODIFY */
package com.siva.animation_sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}